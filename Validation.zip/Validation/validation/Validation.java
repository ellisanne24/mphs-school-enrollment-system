
package validation;

import daoimpl.CurriculumDaoImpl;
import daoimpl.GradeLevelDaoImpl;
import daoimpl.SchoolYearDaoImpl;
import daoimpl.SubjectDaoImpl;
import java.awt.Color;
import java.util.Calendar;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.InputVerifier;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.curriculum.Curriculum;
import model.gradelevel.GradeLevel;
import model.schoolyear.SchoolYear;
import model.subject.Subject;
import org.jdatepicker.JDatePicker;
import org.jdatepicker.impl.JDatePickerImpl;

/**
 *
 * @author francisunoxx
 */
public class Validation{
    
    int year = Calendar.getInstance().get(Calendar.YEAR);
    
    public boolean validateBirthDate(String module, List<JTextField> tfList, List<JComboBox> cbList, List<JDatePickerImpl> dateList){
        boolean result = true;
        int input = 1;
        int counter = 0;
        
        if(module.equals("registration")){
            //For textfields
            for(int a = 0; a < tfList.size(); a++){
                if(tfList.get(a).getText().equals("") || tfList.get(a).getText() == null){
                    result = true;
                    tfList.get(a).setBorder(BorderFactory.createLineBorder(Color.RED));
                }
            
                else{
                    result = false;
                    tfList.get(a).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                }
            }
            
            //For combobox and datepicker
            if(cbList.get(0).getName() == "gradeLevel"){
                    
                if(cbList.get(0).getSelectedIndex() == -1){
                    cbList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                }
                else if(dateList.get(0).getModel().getValue() == null){
                    dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                }
                
                if(cbList.get(0).getSelectedIndex() != -1){
                    cbList.get(0).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                }
                else if(dateList.get(0).getModel().getValue() != null){
                    dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                }
                
                if(cbList.get(0).getSelectedIndex() == -1 && dateList.get(0).getModel().getValue() == null){
                    cbList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                    dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                    
                    result = false;
                }
                else if(cbList.get(0).getSelectedIndex() != -1 && dateList.get(0).getModel().getValue() != null){
                    cbList.get(0).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                    dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                    
                    if(cbList.get(0).getSelectedItem().equals(0)){
                        if(year - dateList.get(0).getModel().getYear() > 6){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Kindergarten!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 4){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Kindergarten!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(1)){
                        if(year - dateList.get(0).getModel().getYear() > 7){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 1!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 6){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 1!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(2)){
                        if(year - dateList.get(0).getModel().getYear() > 8){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 2!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 7){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 2!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(3)){
                        if(year - dateList.get(0).getModel().getYear() > 9){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 3!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 8){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 3!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(4)){
                        if(year - dateList.get(0).getModel().getYear() > 10){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 4!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 9){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 4!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(5)){
                        if(year - dateList.get(0).getModel().getYear() > 11){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 5!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 10){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 5!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(6)){
                        if(year - dateList.get(0).getModel().getYear() > 12){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 6!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 11){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 6!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(7)){
                        if(year - dateList.get(0).getModel().getYear() > 13){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 7!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 12){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 7!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(8)){
                        if(year - dateList.get(0).getModel().getYear() > 14){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 8!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 13){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 8!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(9)){
                        if(year - dateList.get(0).getModel().getYear() > 15){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 9!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 14){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 9!" + "\n" + "Accept age?");
                        }
                    }
                    else if(cbList.get(0).getSelectedItem().equals(10)){
                        if(year - dateList.get(0).getModel().getYear() > 16){
                            input = JOptionPane.showConfirmDialog(null, "Too old for Grade 10!" + "\n" + "Accept age?");
                        }
                        else if(year - dateList.get(0).getModel().getYear() < 15){
                            input = JOptionPane.showConfirmDialog(null, "Too young for Grade 10!" + "\n" + "Accept age?");
                        }
                    }
                    if(input == 0){ //YES
                        result = true;
                        
                        dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.BLACK));
                    }
                    else if(input == 1){ //NO
                        result = false;
                        
                        dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                    }
                    else{
                        result = false;
                        
                        dateList.get(0).setBorder(BorderFactory.createLineBorder(Color.RED));
                    }
                }
            }
        }

        
        return result;
    }
}
